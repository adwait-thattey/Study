<?php
    /***************************************************************
     * register0.php
     *
     * Dumps contents of $_POST.
     ***************************************************************/

?>

<!DOCTYPE html>

<html>
  <head>
    <title>Groups</title>
  </head>
  <body>
    <pre>
      <?php print_r($_POST); ?>
    </pre>
  </body>
</html>
