package main

import (
	"bufio"
	"encoding/json"
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"github.com/davecgh/go-spew/spew"
)

func handleConn(conn net.Conn) {

	defer conn.Close()

	io.WriteString(conn, "Enter new Balance:")

	scanner := bufio.NewScanner(conn)

	// take in BPM from stdin and add it to blockchain after conducting necessary validation
	go func() {
		for scanner.Scan() {
			balance, err := strconv.Atoi(scanner.Text())
			
			newBlock, err := GenerateBlock(Blockchain[len(Blockchain)-1], balance)
			
			if CheckBlockValid(newBlock, Blockchain[len(Blockchain)-1]) {
				newBlockchain := append(Blockchain, newBlock)
				ReplaceChain(newBlockchain)
			}

			BcServer <- Blockchain
			io.WriteString(conn, "\nEnter new Balance:")
		}
	}()

	// simulate receiving broadcast
	go func() {
		for {
			time.Sleep(10 * time.Second)
			mutex.Lock()
			output, err := json.Marshal(Blockchain)
			mutex.Unlock()
			io.WriteString(conn, string(output) + "\n\n")
		}
	}()

	for _ = range BcServer {
		spew.Dump(Blockchain)
	}

}

func StartServer() {
	server, err := net.Listen("tcp", ":"+"8000")

	if err != nil {
		log.Fatal(err)
	}
	log.Println("Server listening on port 8000")

	defer server.Close()

	for {
		conn, err := server.Accept()
		if err != nil {
			log.Fatal(err)
		}
		go handleConn(conn)
	}
}
