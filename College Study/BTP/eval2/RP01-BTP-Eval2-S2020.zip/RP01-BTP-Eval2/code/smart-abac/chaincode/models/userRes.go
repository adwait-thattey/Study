package models

import "encoding/json"

// Define the resource structure
type UserResponse struct {
	Timestamp int64  `json:"timestamp"`
	Token	  string `json:"token"`
	URL       string `json:"url"`
}

func (r UserResponse) ToBytes() []byte {
	b, err := json.Marshal(r)
	if err != nil {
		return nil
	}
	return b
}

func NewResponse(b []byte) (UserResponse, error) {
	r := UserResponse{}
	err := json.Unmarshal(b, &r)
	return r, err
}
