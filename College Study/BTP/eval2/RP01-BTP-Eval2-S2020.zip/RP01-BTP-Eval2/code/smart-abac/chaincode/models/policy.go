package models

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
)

type Policy struct {
	ua UserAttributes
	da DeviceAttributes
	ea EnvironmentAttributes
	permission int //1 is allow , 0 is deney
}

type UserAttributes struct {
	UserId string `json:"userId"`
	Role   string `json:"role"`
	Group  string `json:"group"`
}

type DeviceAttributes struct {
	DeviceId string `json:"deviceId"`
	MAC      string `json:"MAC"`
}

type EnvironmentAttributes struct {
	CreatedTime int64    `json:"createdTime"`
	EndTime     int64    `json:"endTime"`
	AllowedIPs  []string `json:"allowedIPs"`
}

func (p *Policy) ToBytes() []byte {
	b, err := json.Marshal(*p)
	if err != nil {
		return nil
	}
	return b
}

func (p *Policy) GetID() string {
	return fmt.Sprintf("%x", sha256.Sum256([]byte(p.ua.UserId+p.da.DeviceId)))
}
