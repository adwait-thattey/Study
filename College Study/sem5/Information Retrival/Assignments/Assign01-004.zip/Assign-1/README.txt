Please run main.py file to start

> python3 main.py

Compatible with python 3.6 and above

The permuterm index has been implemented using a B+Tree

