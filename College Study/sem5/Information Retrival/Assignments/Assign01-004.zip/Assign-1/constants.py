documents_directory_name = "documents"
useless_character_list = ['\n', '.', ',', "'", '"', ';', '/', '?', '(', ')', '$', '*', '@']
special_characters = ['*', '$']
btree_node_size = 3