import re
import os
import random
from math import log10
from nltk.corpus import stopwords

def pre_process(terms):
    stop_words = list(stopwords.words('english')) 
    imp_words = []
    for word in terms:
        word = word.lower()
        word = re.sub("[^0-9a-zA-Z-]+", "", word)
        if word in stop_words:
            continue
        imp_words.append(word)
    return imp_words

def get_word_freq(files_list):
    word_doc_freq = dict()
    word_freq = dict()
    for file in files_list:
        f = open('documents/' + file,'r')
        words = f.read().split()
        words = pre_process(words)
        for word in words:
            if word in word_freq:
                word_doc_freq[word][file] = word_doc_freq[word].get(file,0) + 1
            else:
                word_doc_freq[word] = {file: 1} 
            word_freq[word] = word_freq.get(word,0) +1
    return word_doc_freq, word_freq

def termfreq(query, word_doc_freq, docs, choice=0, th=0):
    terms   = dict()
    print("Ranking of documents ")
    if choice == 0:
        print("By Raw-TF")
        j = 0
        while j < len(docs):
            score = 0
            for word in query:
                if word in word_doc_freq:
                    if docs[j] in word_doc_freq[word]:
                        score += word_doc_freq[word][docs[j]]
            terms  [docs[j]] = [docs[j], score]     
            j += 1       


    elif choice == 1:
        print("By Log-TF")
        for i in docs:
            score = 0
            for word in query:
                if word in word_doc_freq:
                    if i in word_doc_freq[word]:
                        score +=  log10(1 + word_doc_freq[word][i] )
            terms [i] = [i, score]

    elif choice == 2:
        print("By Binary-TF")
        for i in docs:
            score = 0
            for word in query:
                if word in word_doc_freq:
                    if i in word_doc_freq[word]:
                        score += 1
                terms[i] = [i, score]
    
    elif choice == 3:
        print("By Augmented-TF")
        for i in docs:
            score = 0
            for word in query:
                if word in word_doc_freq:
                    if i in word_doc_freq[word]:
                        mx = max([dc.get(i,0) for dc in word_doc_freq.values() ])
                        score += th + (1-th)*word_doc_freq[word][i]/mx
            
            terms[i] = [i, score]

    elif choice == 4:
        print("By Okapi-TF")
        for i in docs:
            score = 0
            for word in query:
                if word in word_doc_freq:
                    if i in word_doc_freq[word]:
                        tf = word_doc_freq[word][i]
                        score += tf/(2+tf)
            terms[i] = [i, score]
    
    print([(i,j[-1]) for i, j in sorted(terms.items(), key = lambda kv:(kv[1][-1], kv[0] ), reverse=True)])

dir_name = 'documents'


files_list = os.listdir(dir_name)
print(files_list)
word_doc_freq, word_freq = get_word_freq(files_list)
if '' in word_doc_freq:
	del word_doc_freq['']
	del word_freq['']
top_20_freq = [i for i, j in sorted(word_freq.items(), key = lambda kv:(kv[1], kv[0] ), reverse=True)][:20]
least_20_freq = [i for i, j in sorted(word_freq.items(), key = lambda kv:(kv[1], kv[0] ))][:20]
print('most frequent words:', top_20_freq)
print()
print('least frequent words:', least_20_freq)
def gen_qeury(top_20_freq, least_20_freq):
    query = []
    i1 = random.randint(0,len(top_20_freq)-1)
    i2 = random.randint(0,min(len(top_20_freq),len(least_20_freq))-1)
    i3 = random.randint(0,len(least_20_freq)-1)
    sel_list = random.randint(0,1)
    if sel_list == 0:
        query.append(top_20_freq[i1])
        query.append(top_20_freq[i2])
        query.append(least_20_freq[i3])
    else:
        query.append(top_20_freq[i1])
        query.append(least_20_freq[i2])
        query.append(least_20_freq[i3])
    return query

query = gen_qeury(top_20_freq, least_20_freq)

print(query)
inp = input("Enter choice: \
            \n0 for Raw-TF \
            \n1 for Log-TF \
            \n2 for Binary-TF \
            \n3 for Augmented-TF \
            \n4 for Okapi-TF:\n")

if inp != '3':
    print(termfreq(query, word_doc_freq, files_list, int(inp)))
elif inp == '3':
    th = float(input("Enter threshold: "))
    print(termfreq(query, word_doc_freq, files_list, 3, th))
else:
    print('please check the input')