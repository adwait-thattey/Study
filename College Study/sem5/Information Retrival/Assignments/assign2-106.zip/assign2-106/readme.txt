Ranking of documents based on term frequency:
1) Raw tf - the raw count of the tern in a document.
2) log tf - Uses term weighting. Uses a log based function for inverse docoment frequency.
3) Binary tf - Similar to bag of words
4) Augmented tf - Divides tf by max tf and returns if above threshhold.
5) okapi tf - uses score = (tf/2+tf)


Queries will be generated randomly. It will have atleast 1 term from the most frequent words and 1 term from the least frequent terms. 