STOP_WORDS_FILE = "./stop_words.txt"
DOCUMENT_DIR = 'documents'