to run:
> python3 main.py
compatible with python 3.6 and above

5 tf measures are used for ranking
1) Raw tf 
2) log tf
3) Binary tf 
4) Augmented tf
5) okapi tf 


Querires are generated randomly
