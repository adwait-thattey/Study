
GRAPH_NODES = dict()
HEURISTIC = dict() # a dict of dict containing the distances
NODE_ID = 0
START_NODE = None

# for 8 puzzle
FINAL_STATE_POS = dict()