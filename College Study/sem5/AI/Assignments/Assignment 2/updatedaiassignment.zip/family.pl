child("eddard stark","rickard stark").
child("brandon stark","rickard stark").
child("benjen stark","rickard stark").
child("lyanna stark","rickard stark").
child("eddard stark","lyarra stark").
child("brandon stark","lyarra stark").
child("benjen stark","lyarra stark").
child("lyanna stark","lyarra stark").

child("robb stark","eddard stark").
child("sansa stark","eddard stark").
child("arya stark","eddard stark").
child("bran stark","eddard stark").
child("rickon stark","eddard stark").
child("robb stark","catelyn stark").
child("sansa stark","catelyn stark").
child("arya stark","catelyn stark").
child("bran stark","catelyn stark").
child("rickon stark","catelyn stark").

child("rhaegar targaryen","aerys targaryen").
child("viserys targaryen","aerys targaryen").
child("daenerys targaryen","aerys targaryen").
child("rhaegar targaryen","rhaella targaryen").
child("viserys targaryen","rhaella targaryen").
child("daenerys targaryen","rhaella targaryen").

child("jon snow","rhaegar targaryen").
child("jon snow","lyanna stark").

child("rhaenys targaryen","rhaegar targaryen").
child("aegon targaryen","rhaegar targaryen").
child("rhaenys targaryen","elia martell").
child("aegon targaryen","eliam artell").

spouse("eddard stark","catelyn stark").
spouse("catelyn stark","eddard stark").
spouse("lyanna stark","rhaegar targaryen").
spouse("rhaegar targaryen","lyanna stark").
spouse("rhaegar targaryen","elia martell").
spouse("elia martell","rhaegar targaryen").
spouse("rickard stark","lyarra stark").
spouse("lyarra stark","rickard stark").
spouse("aerys targaryen","rhaella targaryen").
spouse("rhaella targaryen","aerys targaryen").

female("lyarra stark").
female("catelyn stark").
female("lyanna stark").
female("sansa stark").
female("arya stark").
female("rhaella targaryen").
female("elia martell").
female("daenerys targaryen").
female("rhaenys targaryen").

male("rickard stark").
male("eddard stark").
male("brandon stark").
male("benjen stark").
male("robb stark").
male("bran stark").
male("rickon stark").
male("jon snow").
male("aerys targaryen").
male("rhaegar targaryen").
male("viserys targaryen").
male("aegon targaryen").



husband(X,Y):-
  male(X),spouse(X,Y).

wife(X,Y):-
  female(X),spouse(X,Y).

brothers(X,Y):-
  male(X),male(Y),mother(Parent,X),mother(Parent,Y), father(P2, X), father(P2,Y), X \= Y.

sisters(X,Y):-
  female(X),female(Y),mother(Parent,X),mother(Parent,Y), father(P2, X), father(P2,Y), X \= Y.

siblings(X,Y):-
  ((female(X) , male(Y)) ; (male(X) , female(Y))) ,mother(Parent,X),mother(Parent,Y), father(P2, X), father(P2,Y), X\=Y .

mother(X,Y):-
  female(X) , child(Y,X).

father(X,Y):-
  male(X) , child(Y,X).

aunt(X,Y):-
  female(X) , (siblings(X,Parent);sisters(X,Parent)) , child(Y,Parent).

uncle(X,Y):-
  male(X) , (siblings(X,Parent);brothers(X,Parent)) , child(Y,Parent).

grandchild(X,Y):-
  child(Parent,Y) , child(X,Parent).

grandson(X,Y):-
  male(X) , grandchild(X,Y).

granddaughter(X,Y):-
  female(X) , grandchild(X,Y).

descendant(X,Y):-
  child(X,Y) ; (child(X,Parent) , descendant(Parent,Y)).