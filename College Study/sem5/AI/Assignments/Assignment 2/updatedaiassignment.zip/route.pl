
edge("karhold","gulltown").
edge("karhold","braavaos").
edge("braavaos","gulltown").
edge("gulltown","tyrosh").
edge("braavaos","tyrosh").
edge("tyrosh","dorne").
edge("tyrosh","volantis").
edge("volantis","dorne").

reachableHelper(City1,City2,Visited) :-
  edge(City1,X) , not(member(X,Visited)) , ( City2 = X ; reachableHelper(X,City2,[City1|Visited]) ) , !.

reachable(City1,City2) :-
  reachableHelper(City1,City2,[]).

fasterReachable(City1,City2,[City1,City2]):-
  edge(City1,City2).
fasterReachable(City1,City2,Path) :-
  edge(City1,Second),fasterReachable(Second,City2,RemainingPath),Path = [City1|RemainingPath].